"""Platform-specific wallpaper backends."""
