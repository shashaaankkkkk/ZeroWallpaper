"""Core modules for ZeroWallpaper."""
